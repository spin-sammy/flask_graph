a_key = 'jHY8JQZHCrlIAZ6ZpeTU0fbi635XlOEPXZhl4sqmMxKYDE4MptTsP3GCIPzYVz4t'
a_secret = 'tGudEvSOjlKq0znQ9kdz1ZVnBPzAOUl836zPQFJcAyqeSscUnedrrs5KLHyehT0f'
f_pairs = [ 'ADAUSDT',
            'DOGEUSDT'
            ]